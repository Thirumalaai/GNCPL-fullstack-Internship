
console.log("Portfolio loaded successfully.");
